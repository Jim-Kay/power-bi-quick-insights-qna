GO
PRINT N'Creating [pbiSales]...'


GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'pbiSales')
EXEC sys.sp_executesql N'CREATE SCHEMA [pbiSales]'

GO

PRINT N'Dropping existing pbiSales views...'
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[City]'))          DROP VIEW [pbiSales].[City]
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Customer]'))      DROP VIEW [pbiSales].[Customer]
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Date]'))          DROP VIEW [pbiSales].[Date]          --Used for 'UseRelationship' Approach
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Invoice Date]'))  DROP VIEW [pbiSales].[Invoice Date]  --Used for 'Role-Playing' Approach
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Delivery Date]')) DROP VIEW [pbiSales].[Delivery Date] --Used for 'Role-Playing' Approach
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Salesperson]'))   DROP VIEW [pbiSales].[Salesperson]
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Stock Item]'))    DROP VIEW [pbiSales].[Stock Item]
IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[pbiSales].[Sales]'))         DROP VIEW [pbiSales].[Sales]

GO

PRINT N'Creating [pbiSales].[City]...'
GO
CREATE VIEW [pbiSales].[City]
AS
SELECT
  [City Key]                   AS [_CityKey],
  [City]                       AS [City],
  [State Province]             AS [State], --All sales are currently in the U.S.
  [Country]                    AS [Country],
  [Continent]                  AS [Continent],
  [Sales Territory]            AS [Sales Territory],
  [Region]                     AS [Region],
  [Subregion]                  AS [Subregion],
  CASE --Create 'Filter Buckets' for City Population
	WHEN [Latest Recorded Population] = 0 THEN       'No Population Recorded'
	WHEN [Latest Recorded Population] < 5000 THEN    'Population Less than 5,000'
	WHEN [Latest Recorded Population] < 25000 THEN   'Population of 5,000-24,999'
	WHEN [Latest Recorded Population] < 100000 THEN  'Population of 25,000-99,999'
	WHEN [Latest Recorded Population] < 500000 THEN  'Population of 100,000-499,999'
	WHEN [Latest Recorded Population] < 1000000 THEN 'Population of 500,000-999,999'
	WHEN [Latest Recorded Population] < 3000000 THEN 'Population of 1 Million-3 Million'
	WHEN [Latest Recorded Population] < 6000000 THEN 'Population of 3 Million-6 Million'
	ELSE 'Population Over 6 Million'
  END						   AS [Sales City Population Size],
  CASE --Create an 'Order By' field for City Population
	WHEN [Latest Recorded Population] = 0 THEN       0
	WHEN [Latest Recorded Population] < 5000 THEN    1
	WHEN [Latest Recorded Population] < 25000 THEN   2
	WHEN [Latest Recorded Population] < 100000 THEN  3
	WHEN [Latest Recorded Population] < 500000 THEN  4
	WHEN [Latest Recorded Population] < 1000000 THEN 5
	WHEN [Latest Recorded Population] < 3000000 THEN 6
	WHEN [Latest Recorded Population] < 6000000 THEN 7
	ELSE 8
  END                          AS [PopulationSizeOrder]

  --Fields not exposed to Power BI------------------------------------------------------------
  --[WWI City ID], --Natural Key - Not Needed
  --[Location],    --Geo-Location - Not currently supported by PBI
  --[Valid From],  --Surrogate Key Date - Not Needed for Power BI
  --[Valid To],    --Surrogate Key Date - Not Needed for Power BI
  --[Lineage Key], --ETL Tracing Key    - Not Needed for Power BI
FROM [Dimension].[City]

GO

PRINT N'Creating [pbiSales].[Customer]...';
GO
CREATE VIEW [pbiSales].[Customer]
	AS 
SELECT 
  [Customer Key]     AS [_CustomerKey],
  [Customer]         AS [Customer Business Name],
  [Category]         AS [Customer Category],
  [Buying Group]     AS [Customer Group],
  [Primary Contact]  AS [Customer Contact],
  [Postal Code]      AS [Customer Zip Code]  --Renamed to U.S. only term

  --Fields not exposed to Power BI------------------------------------------------------------
  --[WWI Customer ID]  --Natural Key - Not Needed
  --[Bill To Customer] --This is just a more verbose version of [Buying Group]
  --[Valid From]       --Surrogate Key Date - Not Needed for Power BI
  --[Valid To]         --Surrogate Key Date - Not Needed for Power BI
  --[Lineage Key]      --ETL Tracing Key    - Not Needed for Power BI

FROM [Dimension].[Customer]
GO

PRINT N'Creating [pbiSales].[Date]...';
GO

CREATE VIEW [pbiSales].[Date]
AS

--Using a CTE in an attempt to simplify 
WITH date_cte (_date, _date_name, _day, _d_num, _month, _short_month, _m_num, _q_num, _y_num, _year, _dow_num, _day_of_week)
AS
(
	SELECT
	  [Date]                                     AS _date,
	  CONVERT(NVARCHAR(11),[Date],106)           AS _date_name,
	  [Day]                                      AS _day,       
	  [Day Number]                               AS _d_num,
	  [Month]                                    AS _month,
	  [Short Month]                              AS _short_month,
	  [Calendar Month Number]                    AS _m_num,
	  CEILING(([Calendar Month Number] + 0.0)/3) AS _q_num,
	  [Calendar Year]                            AS _y_num,
	  CONVERT (NVARCHAR(4),[Calendar Year])      AS _year,
	  DATEPART(weekday,[Date])                   AS _dow_num,
	  DATENAME(weekday,[Date])                   AS _day_of_week
	  --Fields not exposed to Power BI------------------------------------------------------------
	  --[Fiscal Month Number],
	  --[Fiscal Month Label],
	  --[Fiscal Year],
	  --[Fiscal Year Label],
	  --[ISO Week Number]
	FROM [Dimension].[Date]	
)

SELECT
  _date                                       AS [_DateKey],
  _date                                       AS [Date],
  _date_name                                  AS [Date Name],
  _day                                        AS [Day],
  _month                                      AS [Month],
  _short_month                                AS [Short Month],
  CASE 
	WHEN _m_num <=3 THEN 'Q1'
	WHEN _m_num <=6 THEN 'Q2'
	WHEN _m_num <=9 THEN 'Q3'
	                ELSE 'Q4'
  END                                         AS [Quarter],
  _year                                       AS [Year],
  CASE 
	WHEN _m_num <=3 THEN 'Q1-' + _year
	WHEN _m_num <=6 THEN 'Q2-' + _year
	WHEN _m_num <=9 THEN 'Q3-' + _year
	                ELSE 'Q4-' + _year
  END                                         AS [Quarter Year],
  _short_month + '-' + _year                  AS [Month Year],
  _day_of_week                                AS [Day of Week],
  SUBSTRING(_day_of_week,1,3)                 AS [Short Day of Week],
  CASE
	WHEN 
		_dow_num = 1 OR _dow_num = 7
	THEN	
		'Weekend'
	ELSE 
		'Weekday'
  END                                         AS [Type of Day],
  _d_num                                      AS [DayNumber],
  _dow_num                                    AS [DayOfWeekNumber],
  _m_num                                      AS [MonthNumber],
  _q_num                                      AS [QuarterNumber],
  _y_num                                      AS [YearNumber],
  (_y_num * 10)  + _q_num                     AS [QuarterYearNumber],
  (_y_num * 100) + _m_num                     AS [MonthYearNumber],
  (_y_num * 10000) + (_m_num * 100) + _d_num  AS [MonthYearDayNumber]
FROM date_cte

GO


PRINT N'Creating [pbiSales].[Invoice Date]...';
GO
CREATE VIEW [pbiSales].[Invoice Date]
AS
SELECT [Date]                   AS [_InvoiceDateKey],
       [Date]                   AS [Invoice Date],
	   [Date Name]              AS [Invoice Date Name],
       [Day]                    AS [Invoice Day],
       [Month]                  AS [Invoice Month],
       [Short Month]            AS [Invoice Short Month],
       'Inv. ' + [Quarter]      AS [Invoice Quarter],
       'Inv. ' + [Year]         AS [Invoice Year],
       'Inv. ' + [Quarter Year] AS [Invoice Quarter Year],
       'Inv. ' + [Month Year]   AS [Invoice Month Year],
       [Day of Week]            AS [Invoice Day of Week],
       [Short Day of Week]      AS [Invoice Short Day of Week],
       [Type of Day]            AS [Invoice Type of Day],
       [DayNumber]              AS [Invoice DayNumber],
       [QuarterNumber]          AS [Invoice QuarterNumber],
	   [QuarterYearNumber]      AS [Invoice QuarterYearNumber],
       [MonthNumber]            AS [Invoice MonthNumber],
       [YearNumber]             AS [Invoice YearNumber],
       [MonthYearNumber]        AS [Invoice MonthYearNumber],
       [MonthYearDayNumber]     AS [Invoice MonthYearDayNumber],
       [DayOfWeekNumber]        AS [Invoice DayOfWeekNumber]
  FROM [pbiSales].[Date]
  
GO

PRINT N'Creating [pbiSales].[Delivery Date]...';
GO
CREATE VIEW [pbiSales].[Delivery Date]
AS
SELECT [Date]                   AS [_DeliveryDateKey],
       [Date]                   AS [Delivery Date],
	   [Date Name]              AS [Delivery Date Name],
       [Day]                    AS [Delivery Day],
       [Month]                  AS [Delivery Month],
       [Short Month]            AS [Delivery Short Month],
       'Del. ' + [Quarter]      AS [Delivery Quarter],
       'Del. ' + [Year]         AS [Delivery Year],
       'Del. ' + [Quarter Year] AS [Delivery Quarter Year],
       'Del. ' + [Month Year]   AS [Delivery Month Year],
       [Day of Week]            AS [Delivery Day of Week],
       [Short Day of Week]      AS [Delivery Short Day of Week],
       [Type of Day]            AS [Delivery Type of Day],
       [DayNumber]              AS [Delivery DayNumber],
       [QuarterNumber]          AS [Delivery QuarterNumber],
	   [QuarterYearNumber]      AS [Delivery QuarterYearNumber],
       [MonthNumber]            AS [Delivery MonthNumber],
       [YearNumber]             AS [Delivery YearNumber],
       [MonthYearNumber]        AS [Delivery MonthYearNumber],
       [MonthYearDayNumber]     AS [Delivery MonthYearDayNumber],
       [DayOfWeekNumber]        AS [Delivery DayOfWeekNumber]
  FROM [pbiSales].[Date]  
GO

PRINT N'Creating [pbiSales].[Salesperson]...';
GO
CREATE VIEW [pbiSales].[Salesperson]
AS 
SELECT
  [Employee Key]    AS [_SalespersonKey],
  [Employee]        AS [Salesperson Name]

  --Fields not exposed to Power BI------------------------------------------------------------
  --[WWI Employee ID] --Natural Key - Not Needed
  --[Preferred Name]  --I'd use this instead of full name, but we hired too many 'Hudsons'
  --[Photo]           --Not Populated in Dataset 
  --[Is Salesperson]  --No need to display this - these are all salespeople
  --[Valid From]      --Surrogate Key Date - Not Needed for Power BI
  --[Valid To]        --Surrogate Key Date - Not Needed for Power BI
  --[Lineage Key]     --ETL Tracing Key    - Not Needed for Power BI
FROM [Dimension].[Employee]
WHERE [Is Salesperson] = 1
GO

PRINT N'Creating [pbiSales].[Stock Item]...';
GO

CREATE VIEW [pbiSales].[Stock Item]
AS
SELECT
  [Stock Item Key]           AS [_StockItemKey],
  [Stock Item]               AS [Stock Item Name],
  [Color]                    AS [Stock Item Color],
  CASE --Change to more descriptive values
	WHEN [Selling Package] = 'Each'   THEN 'Sold Individually Packaged'
	WHEN [Selling Package] = 'Packet' THEN 'Sold as Box of Items'
	WHEN [Selling Package] = 'Bag'    THEN 'Sold as Bag of Items'
	WHEN [Selling Package] = 'Pair'   THEN 'Sold as Pair of Items'
	WHEN [Selling Package] = 'N/A'    THEN 'N/A'            --This only applies to the 'Unknown' member
  END                        AS [Selling Package],
  CASE --Change to more descriptive values
	WHEN [Buying Package] = 'Each'    THEN 'Bought Individually Packaged'
	WHEN [Buying Package] = 'Packet'  THEN 'Bought as Box of Items'
	WHEN [Buying Package] = 'Carton'  THEN 'Bought as Carton of Items'
	WHEN [Buying Package] = 'N/A'     THEN 'N/A'             --This only applies to the 'Unknown' member
  END                        AS [Buying Package],
  CASE --Boolean Expanded to more descrptive values
	WHEN [Is Chiller Stock] = 1       THEN 'Must Refrigerate'
	WHEN [Is Chiller Stock] = 0       THEN 'Room Temp. Storage'
  END                        AS [Storage Requirement],
  [Brand]                    AS [Brand],
  [Size]                     AS [Size],
  [Lead Time Days]           AS [LeadTimeDays],           --Potential Measure
  [Quantity Per Outer]       AS [QuantityPerOuter],       --Potential Measure
  [Tax Rate]                 AS [TaxRate],                --Potential Measure
  [Unit Price]               AS [UnitPrice],              --Potential Measure
  [Recommended Retail Price] AS [RecommendedRetailPrice], --Potential Measure
  [Typical Weight Per Unit]  AS [TypicalWeightPerUnit]    --Potential Measure

  --Fields not exposed to Power BI------------------------------------------------------------
  --[WWI Stock Item ID] --Natural Key
  --[Barcode]           --Natural Key
  --[Photo]             --Not Populated in Dataset 
  --[Valid From]        --Surrogate Key Date - Not Needed for Power BI
  --[Valid To]          --Surrogate Key Date - Not Needed for Power BI
  --[Lineage Key]       --ETL Tracing Key    - Not Needed for Power BI
FROM [Dimension].[Stock Item]

GO


PRINT N'Creating [pbiSales].[Sales]...';
GO
CREATE VIEW [pbiSales].[Sales]
AS
SELECT
  [Sale Key]             AS [_SaleKey],
  [City Key]             AS [_CityKey],
  [Customer Key]         AS [_CustomerKey],
  [Stock Item Key]       AS [_StockItemKey],
  [Invoice Date Key]     AS [_InvoiceDateKey],
  [Delivery Date Key]    AS [_DeliveryDateKey],
  [Salesperson Key]      AS [_SalespersonKey],
  [Quantity]             AS [QtyLineItem],      --Potential Measure
  [Unit Price]           AS [UnitPrice],         --Potential Measure
  [Tax Rate]             AS [TaxRate],           --Potential Measure
  [Total Excluding Tax]  AS [TotalExcludingTax],--Potential Measure
  [Tax Amount]           AS [TaxAmount],         --Potential Measure
  [Profit]               AS [ProfitLineItem],   --Potential Measure
  [Total Including Tax]  AS [TotalIncludingTax],--Potential Measure
  [Total Dry Items]      AS [TotalDryItems],    --Potential Measure
  [Total Chiller Items]  AS [TotalChillerItems] --Potential Measure

  --Fields not exposed to Power BI------------------------------------------------------------
  --[Bill To Customer Key]  --Bill-To Customer is already an attribute of Customer - so, we can already filter by it...
  --[WWI Invoice ID]        --Natural Key
  --[Description]           --Field exists in Stock Item Dimension,
  --[Package]               --Field Esists in Stock Item Dimension,
  --[Lineage Key]           --ETL Tracing Key    - Not Needed for Power BI

FROM [Fact].[Sale]
GO



PRINT N'Update complete.';

